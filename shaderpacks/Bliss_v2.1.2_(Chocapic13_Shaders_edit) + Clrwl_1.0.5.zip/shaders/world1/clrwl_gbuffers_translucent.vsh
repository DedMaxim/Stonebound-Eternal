#version 120

#define END_SHADER

#define ENTITIES
#define BLOCKENTITIES

#include "/dimensions/clrwl_translucent.vsh"
