#version 400 compatibility
#extension GL_ARB_shader_image_load_store : enable
#define WORLD_NETHER
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_CUTOUT
#define vsh
#include "/program/shadow.vsh"